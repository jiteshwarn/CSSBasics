//created own module,and only one export
// function should be there
module.exports={
add:(a,b)=>a+b,
multiply:(a,b)=>a*b   
};