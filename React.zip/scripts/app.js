var HelloDivComponent = React.createClass({
	render:function(){
		return (<div>
			<ul>
				<li>React</li>
			</ul>
		</div>);
	}
});
ReactDOM.render(React.createElement(HelloDivComponent),document.getElementById('app'));