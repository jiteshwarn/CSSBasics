var getDataObj = {
    getClearQuestdata : function () {
        return $.get("https://api.myjson.com/bins/10v3kl");
    }
}

