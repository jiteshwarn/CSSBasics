var square = function (n) { return n * n; };
