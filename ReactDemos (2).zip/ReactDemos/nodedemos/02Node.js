//creating own module
// ./ is here for current directory
var calculator=require("./calculator");
console.log(calculator.add(4,5));
console.log(calculator.multiply(4,5));