var math = require("./Math");
console.log(math.add(5,6));